package gcumwd.trafficscotlandapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Created by Jamie Glendinning - S1532525
 */


public class RoadworksFragment extends Fragment {

    ListView lvData;
    AutoCompleteTextView textView;
    ArrayList<String> titles;
    ArrayList<String> description;
    ArrayList<String> roadworks;
    ArrayAdapter<String> adapter;
    ImageButton refreshButton;
    RSSItem rssItem2;
    String date;

    public RoadworksFragment() {

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_roadworks, container, false);
        textView = (AutoCompleteTextView) view.findViewById(R.id.search2);
        titles = new ArrayList<String>();
        description = new ArrayList<String>();
        roadworks = new ArrayList<String>();
        lvData = (ListView) view.findViewById(R.id.lvData2);
        new ProcessInBackground().execute();
        refreshButton = (ImageButton) view.findViewById(R.id.imgRefresh2);


        refreshButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                adapter.clear();
                adapter.notifyDataSetChanged();
                new ProcessInBackground().execute();
                textView.setText("");

                //reloads RSS feed and clears the searchbox
            }
        });

        // ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1, titles );
        return view;

    }


    public InputStream getInputStream(URL url) {
        try {
            return url.openConnection().getInputStream();
        } catch (
                IOException e)

        {
            return null;
        }


    }


    public class ProcessInBackground extends AsyncTask<Integer, Void, Exception> {
        ProgressDialog progressDialog = new ProgressDialog(getContext());
        Exception exception = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog.setMessage("Loading RSS Feed...");
            progressDialog.show();
        }

        @Override
        protected Exception doInBackground(Integer... integers) {

            try {

                URL url = new URL("http://trafficscotland.org/rss/feeds/roadworks.aspx");
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                // creates new instance of pull parser factory that allows XML retrieval
                factory.setNamespaceAware(false);
                // parser produced does not support XML namespaces
                XmlPullParser xpp = factory.newPullParser();
                //new instance of parser, extracts xml document data
                xpp.setInput(getInputStream(url), "UTF_8");
                //encoding is in UTF8
                boolean insideItem = false;
                int eventType = xpp.getEventType();
                //when we start reading, it returns the type of current event i.e. tag type

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        if (xpp.getName().equalsIgnoreCase("item")) {
                            insideItem = true;
                        } else if (xpp.getName().equalsIgnoreCase("title")) {
                            if (insideItem) {
                                roadworks.add(xpp.nextText());
                               // rssItem2.setTitle(xpp.nextText());
                            }
                        } else if (xpp.getName().equalsIgnoreCase("description")) {
                            if (insideItem) {
                               // date = xpp.nextText();
                                roadworks.add(xpp.nextText());
                                roadworks.add(" ");
                               // rssItem2.setDescription(xpp.nextText());
                            }
                        } /*else if (xpp.getName().equalsIgnoreCase("georss:point")) {
                            if (insideItem) {
                                //roadworks.add(xpp.nextText());
                                roadworks.add(" ");
                            }
                        }*/
                    } else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item")) {
                        insideItem = false;
                    }

                    eventType = xpp.next();
                }

            } catch (MalformedURLException e) {
                exception = e;
            } catch (XmlPullParserException e) {
                exception = e;
            } catch (IOException e) {
                exception = e;
            }


            return exception;
        }

        @Override
        protected void onPostExecute(Exception s) {
            super.onPostExecute(s);
            if(roadworks != null) {
                adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, roadworks);
                Toast.makeText(getContext(), "Data load complete", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "No RSS Data", Toast.LENGTH_SHORT).show();
            }
            lvData.setAdapter(adapter);
            //connects to data to the list view
            progressDialog.dismiss();
            new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, titles);
            textView.setAdapter(adapter);
        }
    }


}
