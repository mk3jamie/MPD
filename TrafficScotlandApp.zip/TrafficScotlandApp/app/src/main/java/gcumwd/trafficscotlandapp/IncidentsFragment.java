package gcumwd.trafficscotlandapp;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Jamie Glendinning - S1532525
 */

public class IncidentsFragment extends Fragment {

    ListView lvData;
    AutoCompleteTextView textView;
    ArrayList<String> titles;
    ArrayList<String> description;
    ArrayList<String> incidents;
    ArrayAdapter<String> adapter;
    ImageButton refreshButton;
    String desc;
    RSSItem rssItem;

    public IncidentsFragment() {

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_incidents, container, false);
        textView = (AutoCompleteTextView) view.findViewById(R.id.search);
        titles = new ArrayList<String>();
        description = new ArrayList<String>();
        incidents = new ArrayList<String>();
        lvData = (ListView) view.findViewById(R.id.lvData);
        new ProcessInBackground().execute();
        refreshButton = (ImageButton) view.findViewById(R.id.imgRefresh);


        refreshButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //lvData.setAdapter(null);
                adapter.clear();
                adapter.notifyDataSetChanged();
                textView.setText("");
                new ProcessInBackground().execute();

                //reloads RSS feed and clears the searchbox
            }
        });

        // ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1, titles );
        return view;


    }


    public InputStream getInputStream(URL url) {
        try {
            return url.openConnection().getInputStream();
        } catch (
                IOException e)

        {
            return null;

        }


    }


    public class ProcessInBackground extends AsyncTask<Integer, Void, Exception> {
        ProgressDialog progressDialog = new ProgressDialog(getContext());
        Exception exception = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog.setMessage("Loading RSS Feed...");
            progressDialog.show();
        }

        @Override
        protected Exception doInBackground(Integer... integers) {

            try {

                URL url = new URL("http://trafficscotland.org/rss/feeds/currentincidents.aspx");
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                // creates new instance of pull parser factory that allows XML retrieval
                factory.setNamespaceAware(false);
                // parser produced does not support XML namespaces
                XmlPullParser xpp = factory.newPullParser();
                //new instance of parser, extracts xml document data
                xpp.setInput(getInputStream(url), "UTF_8");
                //encoding is in UTF8
                boolean insideItem = false;
                int eventType = xpp.getEventType();
                //when we start reading, it returns the type of current event i.e. tag type

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        if (xpp.getName().equalsIgnoreCase("item")) {
                            insideItem = true;
                        } else if (xpp.getName().equalsIgnoreCase("title")) {
                            if (insideItem) {
                                incidents.add(xpp.nextText());
                                //rssItem.setTitle(xpp.nextText());
                            }
                        } else if (xpp.getName().equalsIgnoreCase("description")) {
                            if (insideItem) {
                                //rssItem.setDescription(xpp.nextText());
                                incidents.add(xpp.nextText());
                                incidents.add(" ");
                            }
                        }
                    } else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item")) {
                        insideItem = false;
                    }

                    eventType = xpp.next();
                }

            } catch (MalformedURLException e) {
                exception = e;
            } catch (XmlPullParserException e) {
                exception = e;
            } catch (IOException e) {
                exception = e;
            }


            return exception;
        }

        @Override
        protected void onPostExecute(Exception s) {
            super.onPostExecute(s);
            if (incidents != null) {
                adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, incidents);
                Toast.makeText(getContext(), "Data load complete", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "No RSS Data", Toast.LENGTH_SHORT).show();
            }

            lvData.setAdapter(adapter);
            //connects to data to the list view
            progressDialog.dismiss();
            new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, titles);
            textView.setAdapter(adapter);
        }
    }


}
